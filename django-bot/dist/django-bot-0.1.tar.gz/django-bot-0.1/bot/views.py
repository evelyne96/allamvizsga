from django.shortcuts import render

try:
    import apiai
except ImportError:
    sys.path.append(
        os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir)
    )
    import apiai

CLIENT_ACCESS_TOKEN = 'ba4d6950457e44fba1ac958c7ff19a9d'

# Create your views here.
def index(request):
    ai = apiai.ApiAI(CLIENT_ACCESS_TOKEN)
    request = ai.text_request()
    request.session_id = "12345678"
    request.query = "Joke"

    response = request.getresponse()
    context = {
        'title': "Chatbot.",
        'message': response,
    }
    return render(request, 'index.html', context)
